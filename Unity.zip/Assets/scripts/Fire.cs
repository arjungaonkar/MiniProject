﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire : MonoBehaviour {
    public GameObject player;
    public float bulletspeed=50;

    public float minrecoiltime;
    float recoiltime;
    int count = 0;
    
	public void fire()
    {
        recoiltime = Time.time - recoiltime;

        if (recoiltime > minrecoiltime)
        {
            Transform root = player.transform.GetChild(2);
            GameObject bullet = root.GetChild(count++ % root.childCount).gameObject;
            bullet.GetComponent<Rigidbody>().velocity = Vector3.zero;
            bullet.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
            bullet.transform.position = player.transform.GetChild(1).position;
            bullet.transform.localEulerAngles =player.transform.GetChild(1).eulerAngles;
            bullet.SetActive(true);
            bullet.GetComponent<Rigidbody>().velocity = (player.transform.GetChild(1).forward * bulletspeed);

            
            recoiltime = Time.time;
        }
        
    }

  
}
