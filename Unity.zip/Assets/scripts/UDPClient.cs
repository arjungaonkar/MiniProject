﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public class UDPClient {
    Socket sendSocket;
    UdpClient receiveSocket;

    IPEndPoint sendEP;
    IPEndPoint recieveEP;

    int sendport;
    int recieveport;
    

    Thread t;

   public  UDPClient(string serverIP, int port)
    {  
        this.sendport = port+1;
        this.recieveport = port+2;

        sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        IPAddress serverIPAddress = IPAddress.Parse(serverIP);
        sendEP = new IPEndPoint(serverIPAddress, sendport);

        
       

        receiveSocket = new UdpClient(recieveport);

        recieveEP = new IPEndPoint(IPAddress.Any, recieveport);

        t = new Thread(Run);
        t.Start();
    }

    public void sendToServer(String msg)
    {
        byte[] message = Encoding.ASCII.GetBytes(msg);

        sendSocket.SendTo(message, sendEP);
    }

    void Run()
    {
        //wait for data
        while (true)
        {

            byte[] bytes = receiveSocket.Receive(ref recieveEP);

            MainController.instance.actions.Add(Encoding.ASCII.GetString(bytes, 0, bytes.Length));
        }
    }

    public void stopClient()
    {

        try
        {
            sendSocket.Close();
            sendSocket = null;
        }
        catch { }
        try
        {
            receiveSocket.Close();
            receiveSocket = null;
        }
        catch { }

        finally {
            t.Abort();
        }
       

    }

   
}
