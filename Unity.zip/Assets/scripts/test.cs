﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

public class test : MonoBehaviour {

    void Start()
    {
        Socket sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        IPAddress serverIPAddress = IPAddress.Parse("127.0.0.1");

        int serverPort = 3001;

        IPEndPoint serverEP = new IPEndPoint(serverIPAddress, serverPort);

        String s = "hi";

        byte[] message = Encoding.ASCII.GetBytes(s);

        sendSocket.SendTo(message, serverEP);

       
        int clientPort = 3002;

        UdpClient receiveSocket = new UdpClient(clientPort);

        IPEndPoint clientEP = new IPEndPoint(IPAddress.Any, clientPort);



       
        
            print("Waiting for message: ");

            byte[] bytes = receiveSocket.Receive(ref clientEP);

            print(Encoding.ASCII.GetString(bytes, 0, bytes.Length));
           
    
    }
}
