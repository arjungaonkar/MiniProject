﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class MainController : MonoBehaviour {
    public static MainController instance;

     string ServerIP;
    public int port;

    public TcpClient TCPconnection;
    public UDPClient UDPconnection;
    public List<string> actions;
    string username;
    
    public GameObject UIroot;
    public GameObject _3Droot;

   [Header("Screens")]
    GameObject ActiveScreen;
    GameObject ActiveDScreen;
   
    public GameObject IPScreen;
    public GameObject LoginScreen;
    public GameObject RegisterScreen;
    public GameObject LobbyScreen;
    public GameObject MatchmakingScreen;
    public GameObject ResultScreen;

    [Header("Prefabs")]
    public GameObject NotificationPrefab;
    public GameObject UsernameholderPrefab;
    public GameObject PlayerPrefab;
    
   

    float mtime;
    public float time;


    public int health;

    void Awake()
    {
        if(instance==null)
        {
            instance = this;
        }
        ActiveScreen = IPScreen;
        ActiveDScreen = UIroot;

        
    }

     void Start()
    {
        IPScreen.GetComponentInChildren<TMP_InputField>().text = PlayerPrefs.GetString("ip");    

    }

    void Update()
    {
        while(actions.Count>0)
        {

            actionsFunction(actions[0]);
            actions.RemoveAt(0);
        }

      

        if(Input.GetKeyDown(KeyCode.Escape))
        {
            if (ActiveDScreen == _3Droot)
            {

            }
            else
            {

                if (ActiveScreen == LoginScreen)
                {

                    Application.Quit();
                }
                else if (ActiveScreen == RegisterScreen)
                {
                    changeScreenTo(LoginScreen);
                }
                else if (ActiveScreen == MatchmakingScreen)
                {
                    TCPconnection.sendToServer("cancelmatchmaking/" + username);
                    changeScreenTo(LobbyScreen);
                }
                else if(ActiveScreen==ResultScreen)
                {
                    changeScreenTo(LobbyScreen);
                }
            }
           

        }

         
    }

    void stopTCPConnections()
    {
        try
        {
            TCPconnection.sendToServer("logout");
            TCPconnection.stopClient();


        }
        catch { }
    }

    private void OnApplicationQuit()
    {
        try
        {
            stopTCPConnections();
            UDPconnection.stopClient();

        }
        catch { }
    }

    #region Helper
    public void changeScreenTo(GameObject screen)
    {
        ActiveScreen.SetActive(false);
        ActiveScreen = screen;
        ActiveScreen.SetActive(true);
    }

    public void changeDTo(GameObject mode)
    {
        Destroy(GameObject.FindWithTag("Notification"));
        ActiveDScreen.SetActive(false);
        ActiveDScreen =mode;
        ActiveDScreen.SetActive(true);

    }

    public void showNotification(string msg)
    {
        Destroy(GameObject.FindWithTag("Notification"));
       GameObject g= Instantiate(NotificationPrefab,UIroot.transform);
        g.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = msg;
    }
    #endregion

    #region Network Actions
    void actionsFunction(string data)
    {
        string[] splitdata = data.Split('/');

        switch (splitdata[0])
        {
            case "loginsuccessful":
               loginorregisterSuccessful("Login successful",splitdata);
                StartCoroutine(sendIPforUDP());

                break;

            case "loginunsuccessful":
                if(splitdata.Length>1 && splitdata[1].Equals("piu"))
                {
                    showNotification("Logged in somewhere else");
                }
                else
                {
                    showNotification("Username/Password incorrect");
                }
                
                TCPconnection.stopClient();

                break;

            case "registersuccessful":
                loginorregisterSuccessful("Registertion successful",splitdata);
                StartCoroutine(sendIPforUDP());
                break;

            case "registerunsuccessful":
                showNotification("Username taken");
                TCPconnection.stopClient();

                break;
            case "IPforUDPsuccessful":
                sendIPforUDPrecieve = true;
                print("IP for UDP reicieved");
                break;

            case "deleteaccountsuccessful":
                showNotification("Account deleted");
                changeScreenTo(LoginScreen);
                break;

            case "lobbyupdate":
                lobbyupdate(splitdata);
                break;

            case "buyskinunsuccesful":
                showNotification("Insufficient credit");
                break;

            case "playsuccessful":
                changeScreenTo(MatchmakingScreen);
                break;

            case "letsplay":
                letsplay(splitdata);
                break;

            case "transform":
                
                syncTransform(splitdata);

                break;

            case "bullethit":

                bullethit();
                break;

            case "opponentdied":
                changeScreenTo(ResultScreen);
                changeDTo(UIroot);
                ResultScreen.GetComponentInChildren<TextMeshProUGUI>().text = "You won";


                ///destroy players prefab
                ///
                foreach (GameObject g in players.Values)
                {
                    Destroy(g);
                }


                break;

            default:
                print("Invalid command:" + splitdata[0]);
                break;
        }
    }

   

    void loginorregisterSuccessful(string msg,string[] splitdata)
    {

        showNotification(msg);

        lobbyupdate(splitdata);

        changeScreenTo(LobbyScreen);
        
    }

    void lobbyupdate(string [] splitdata) {
        //set score and credit
        
        LobbyScreen.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = splitdata[1];
        LobbyScreen.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = splitdata[2];


        //set aviable skins active
        Transform root = LobbyScreen.transform.GetChild(6).GetChild(0).GetChild(0).GetChild(0);
        string[] aviable_skins = splitdata[3].Split(',');
        for (int i = 0; i < aviable_skins.Length - 1; i++)
        {
           
            string[] aviable_skins_split = aviable_skins[i].Split(':');
           
            Transform g = root.Find(aviable_skins_split[0]);
            if (g != null)
            {

                g.gameObject.SetActive(true);
                g.GetChild(2).gameObject.SetActive(false);
                selectfromscript = true;
                g.GetChild(2).GetComponent<Toggle>().isOn = false;
                g.GetChild(3).gameObject.SetActive(true);
                g.GetChild(4).gameObject.SetActive(true);
                g.GetChild(5).gameObject.SetActive(true);
                g.GetChild(4).GetComponent<TextMeshProUGUI>().text = aviable_skins_split[1];
            }

        }

        string[] purchased_skins = splitdata[5].Split(',');
        for (int i = 0; i < purchased_skins.Length - 1; i++)
        {
            Transform g = root.Find(purchased_skins[i]);
            if (g != null)
            {
                g.GetChild(2).gameObject.SetActive(true);
                g.GetChild(3).gameObject.SetActive(false);
                g.GetChild(4).gameObject.SetActive(false);
                g.GetChild(5).gameObject.SetActive(false);
            }
        }

        Transform ga = root.Find(splitdata[4]);
        if (ga != null)
        {
            selectfromscript = true;
            ga.GetChild(2).GetComponent<Toggle>().isOn = true;
        }

        //top 15

        root = LobbyScreen.transform.GetChild(4).GetChild(1).GetChild(0).GetChild(0);
        for (int i = 0; i < root.childCount; i++)
        {
            Destroy(root.GetChild(i).gameObject);
        }
        string[] top_players = splitdata[6].Split(',');
        for (int i = 0; i < top_players.Length - 1; i++)
        {
            GameObject g = Instantiate(UsernameholderPrefab, root);
            g.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = (i + 1).ToString();
            g.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = top_players[i];
        }
    }

    float parse(string value)
    {
       return (float)double.Parse(value);
    }

    Dictionary<string, GameObject> players;

    void letsplay(string[] splitdata) {
        players = new Dictionary<string, GameObject>();

        print(splitdata[1] + " " + splitdata[2]);
        GameObject g = Instantiate(PlayerPrefab, _3Droot.transform.GetChild(0));
        g.name = splitdata[1];
        string[] sd = splitdata[1].Split(',');

        print(sd[0]);
        if(!sd[0].Equals(username))
        {
            g.transform.GetChild(1).GetComponent<Player3DExample>().enabled = false;
            
           
            Destroy(g.transform.GetChild(1).GetComponent<Rigidbody>());
            Destroy(g.transform.GetChild(0).gameObject);
        }
        else
        {
            g.transform.GetChild(1).GetComponent<Player3DExample>().joystick = _3Droot.transform.GetChild(3).GetChild(0).GetComponent<FixedJoystick>();
            _3Droot.transform.GetChild(3).GetChild(1).GetComponent<Fire>().player = g;
            Destroy(g.transform.GetChild(1).GetComponent<bulletdetector>());
           
            g.transform.GetChild(1).GetComponent<Player3DExample>().enabled = true;

           
            

        }

        g.transform.GetChild(1).GetChild(int.Parse(sd[1])).gameObject.SetActive(true);

        players.Add(sd[0], g);
        //set the skin

        //sd[1] skin id

        g = Instantiate(PlayerPrefab, _3Droot.transform.GetChild(1));
        g.name = splitdata[2];
        //set the skin
        sd = splitdata[2].Split(',');
        print(sd[0]);
        if (!sd[0].Equals(username))
        {
            g.transform.GetChild(1).GetComponent<Player3DExample>().enabled = false;

            
            Destroy(g.transform.GetChild(1).GetComponent<Rigidbody>());
            Destroy(g.transform.GetChild(0).gameObject);
        }
        else
        {
            g.transform.GetChild(1).GetComponent<Player3DExample>().joystick = _3Droot.transform.GetChild(3).GetChild(0).GetComponent<FixedJoystick>();
            _3Droot.transform.GetChild(3).GetChild(1).GetComponent<Fire>().player = g;
            Destroy(g.transform.GetChild(1).GetComponent<bulletdetector>());
            g.transform.GetChild(1).GetComponent<Player3DExample>().enabled = true;




        }

        g.transform.GetChild(1).GetChild(int.Parse(sd[1])).gameObject.SetActive(true);
        players.Add(sd[0], g);
        //set the skin
        //sd[1] skin id
        health = 100;
        _3Droot.transform.GetChild(3).GetChild(2).GetComponent<Slider>().maxValue = health;
        _3Droot.transform.GetChild(3).GetChild(2).GetComponent<Slider>().value = health;

        changeDTo(_3Droot);
    }


    public void sendtransform(Transform t)
    {
        string msg = "transform" + "/" + username + "/" + t.position.x + "," + t.position.y + "," + t.position.z + "/" + t.eulerAngles.x + "," + t.eulerAngles.y + "," + t.eulerAngles.z;
        Transform bulroot = t.parent.GetChild(2);
        for(int i=0;i<bulroot.childCount;i++)
        {
            Transform b = bulroot.GetChild(i);
            msg +="/"+b.gameObject.activeSelf+"|" + b.position.x + "," + b.position.y + "," + b.position.z + "|" + b.eulerAngles.x + "," + b.eulerAngles.y + "," + b.eulerAngles.z;
        }
        
        UDPconnection.sendToServer(msg);
    }

    void syncTransform(string[] splitdata)
    {
        try
        {
            GameObject g = players[splitdata[1]].transform.GetChild(0).gameObject;
            string[] pos = splitdata[2].Split(',');




            Vector3 newpos = new Vector3(parse(pos[0]), parse(pos[1]), parse(pos[2]));

            string[] eul = splitdata[3].Split(',');
            Vector3 neweul = new Vector3(parse(eul[0]), parse(eul[1]), parse(eul[2]));

            g.transform.position = newpos;
            g.transform.eulerAngles = neweul;




            for (int i = 0; i < 30; i++)
            {
                string[] info = splitdata[i + 3].Split('|');
                if (info[0].Equals("True"))
                {
                    GameObject bul = _3Droot.transform.GetChild(2).GetChild(i).gameObject;
                    bul.SetActive(true);


                    pos = info[1].Split(',');
                    newpos = new Vector3(parse(pos[0]), parse(pos[1]), parse(pos[2]));



                    eul = info[2].Split(',');
                    neweul = new Vector3(parse(eul[0]), parse(eul[1]), parse(eul[2]));

                    bul.transform.position = newpos;
                    bul.transform.eulerAngles = neweul;





                }
                else
                {
                    GameObject bul = _3Droot.transform.GetChild(2).GetChild(i).gameObject;
                    bul.SetActive(false);
                }
            }
        }
        catch
        {

        }

    }

    void bullethit()
    {
        health -= 5;
        _3Droot.transform.GetChild(3).GetChild(2).GetComponent<Slider>().value = health;
        if(health<=0)
        {
            //i died
            print("i died");

            changeScreenTo(ResultScreen);
            changeDTo(UIroot);
            ResultScreen.GetComponentInChildren<TextMeshProUGUI>().text = "You died";


            ///destroy players prefab
            ///
            foreach (GameObject g in players.Values)
            {
                Destroy(g);
            }

            TCPconnection.sendToServer("idied");
        }
    }

    #endregion

    #region UI Actions

    public void ipnextSubmit(TMP_InputField t)
    {  if(t.text=="")
        {
            showNotification("Enter server ip");
            return;
        }
        ServerIP = t.text;
        PlayerPrefs.SetString("ip", t.text);
        UDPconnection = new UDPClient(ServerIP, port);
        changeScreenTo(LoginScreen);
    }

    public void loginSubmit()
    {
        stopTCPConnections();

        string msg = "login/";
        username = LoginScreen.transform.GetChild(0).GetComponent<TMP_InputField>().text;
        string password = LoginScreen.transform.GetChild(1).GetComponent<TMP_InputField>().text;
        if(username=="" || password=="")
        {
            return;
        }

        msg += username+"/"+password;
        
       
        TCPconnection = new TcpClient(ServerIP, port, msg);

        actions = new List<string>();
       
    }

    public void registerSubmit()
    {
        stopTCPConnections();

        string msg = "register/";
        username = RegisterScreen.transform.GetChild(0).GetComponent<TMP_InputField>().text;
        string password = RegisterScreen.transform.GetChild(1).GetComponent<TMP_InputField>().text;
        if (username == "" || password == "")
        {
            return;
        }
        msg += username + "/";
        if(password!= RegisterScreen.transform.GetChild(2).GetComponent<TMP_InputField>().text)
        {
            showNotification("Passwords donot match");
            return;
        }

        msg += RegisterScreen.transform.GetChild(1).GetComponent<TMP_InputField>().text;
        TCPconnection = new TcpClient(ServerIP, port, msg);
        
        actions = new List<string>();
        
    }

    public void deleteaccountSubmit()
    {
        TCPconnection.sendToServer("deleteaccount/"+username);
    }

    public void logoutSubmit()
    {
        TCPconnection.sendToServer("logout");
        TCPconnection.stopClient();
        changeScreenTo(LoginScreen);
    }

    int selectedskinid;
    bool selectfromscript;

    public void selectskinChange(GameObject g)
    {
      
        if (!selectfromscript)
        {
            Toggle t = g.transform.GetChild(2).GetComponent<Toggle>();
            if (t.isOn)
            {
                selectedskinid = int.Parse(g.name);
                TCPconnection.sendToServer("selectskin/" + username + "/" + selectedskinid);
            }
            else
            {
                selectedskinid = -1;
                
            }
           
        }
        else
        {
            selectfromscript = false;
        }
       
    }

    public void buyskinSubmit(GameObject g)
    {
        TCPconnection.sendToServer("buyskin/" + username + "/" + g.name);
    }

    public void playSubmit() {
        if(selectedskinid==-1)
        {
            showNotification("select a skin!");
            return;
        }
        print(selectedskinid);
        //get selected skin and send it;

        //send ur ip
       TCPconnection.sendToServer("play/");
       
    }
    #endregion

    bool sendIPforUDPrecieve;
    IEnumerator sendIPforUDP()
    {
        sendIPforUDPrecieve=false;
        while (!sendIPforUDPrecieve)
        {
           
            UDPconnection.sendToServer("IPforUDP/"+username);
            yield return new WaitForSeconds(2f);
        }
    }
}
