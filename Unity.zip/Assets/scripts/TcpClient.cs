﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class TcpClient {
    string serverIP;
    int port;
    Socket clientSocket;

    Thread t;

   

    public TcpClient(string serverIP,int port,string intialmsg) {
        this.serverIP = serverIP;
        this.port = port;

        IPEndPoint serverAddress = new IPEndPoint(IPAddress.Parse(this.serverIP), this.port);

        clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        clientSocket.Connect(serverAddress);

        //send connect
       
         sendToServer(intialmsg);
        
         t = new Thread(Run);
         t.Start();



    }


    public void sendToServer(string msg)
    {
       
        int toSendLen = System.Text.Encoding.ASCII.GetByteCount(msg);
        byte[] toSendBytes = System.Text.Encoding.ASCII.GetBytes(msg);
        byte[] toSendLenBytes = System.BitConverter.GetBytes(toSendLen);
        clientSocket.Send(toSendLenBytes);
        clientSocket.Send(toSendBytes);
        
        
    }

    void Run()
    {  
        //wait for data
        while (true)
        {

            byte[] rcvLenBytes = new byte[4];
            clientSocket.Receive(rcvLenBytes);

            int rcvLen = System.BitConverter.ToInt32(rcvLenBytes, 0);
            byte[] rcvBytes = new byte[rcvLen];
            clientSocket.Receive(rcvBytes);
            String rcv = System.Text.Encoding.ASCII.GetString(rcvBytes);

            
            MainController.instance.actions.Add(rcv);
        }
    }

   public void stopClient()
    {
        try
        {  
            clientSocket.Close();
           
        }
        catch
        {

        }
        finally {
            t.Abort();
        }
       

        
    }
}
