﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class bound : MonoBehaviour
{

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "bullet" || other.tag == "opponent bullet")
        {
            other.gameObject.SetActive(false);
            
        }
    }
}
