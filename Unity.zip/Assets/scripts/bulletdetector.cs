﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletdetector : MonoBehaviour {
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "bullet")
        {
            other.gameObject.SetActive(false);
            

            MainController.instance.TCPconnection.sendToServer("bullethit");
        }
    }
}
