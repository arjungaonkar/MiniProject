﻿using UnityEngine;

public class Player3DExample : MonoBehaviour {

    public float moveSpeed = 8f;
    public Joystick joystick;
    public GameObject cam;

    public float minsendrate;
    float sendrate;

	void Update () 
	{
        Vector3 moveVector = (Vector3.right * joystick.Horizontal + Vector3.forward * joystick.Vertical);

        if (moveVector != Vector3.zero )
        {
           

            transform.rotation = Quaternion.LookRotation(moveVector);
            transform.Translate(moveVector * moveSpeed * Time.deltaTime, Space.World);

            cam.transform.position = transform.position;

            

        }
        sendrate = Time.time - sendrate;
        if(sendrate>minsendrate)
        {
            MainController.instance.sendtransform(transform);
            sendrate = Time.time;
        }
        


    }

   
}